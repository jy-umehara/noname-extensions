extension["偶像梦幻祭"]={
	intro:"《偶像梦幻祭》是一款乐元素公司（Happy Elements）研发的女性向偶像养成音乐手游",
	author:"小叶",
	netdisk:"",
	forum:"",
	version:"0.12",
	files:["shiratoriaira.jpg","hakazekaoru.jpg","kanzakisouma.jpg","fushimiyuzuru.jpg","ayasemayoi.jpg",
		"rannagisa.jpg","sakumarei.jpg","amagirinne.jpg","aoihinata.jpg","aoiyuuta.jpg",
		"himeru.jpg","otogariadonis.jpg","shiinaniki.jpg","kiryukuro.jpg","hasumikeito.jpg",
		"tenshouineichi.jpg","ogamikoga.jpg","himemiyatori.jpg","saegusaibara.jpg","hibikiwataru.jpg",
		"sazanamijun.jpg","oukawakohaku.jpg","kazehayatatsumi.jpg","hidakahokuto.jpg","amagihiiro.jpg",
		"tomoehiyori.jpg","extension.js","MAIN.JS","package.js","礼濑真宵.jpg","风早巽.jpg"],
	size:"20.1MB"
};