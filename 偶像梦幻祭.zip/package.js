extension["偶像梦幻祭"]={
	intro:"《偶像梦幻祭》是一款乐元素公司（Happy Elements）研发的女性向偶像养成音乐手游",
	author:"小叶",
	netdisk:"https://github.com/jy-umehara/noname-extensions/raw/main/%E5%81%B6%E5%83%8F%E6%A2%A6%E5%B9%BB%E7%A5%AD.zip",
	forum:"",
	version:"0.5",
	files:["kanzakisouma.jpg","fushimiyuzuru.jpg","ayasemayoi.jpg","rannagisa.jpg","himeru.jpg",
		"sakumarei.jpg","kiryukuro.jpg","amagirinne.jpg","ogamikoga.jpg","tenshouineichi.jpg",
		"himemiyatori.jpg","oukawakohaku.jpg","kazehayatatsumi.jpg","hidakahokuto.jpg","amagihiiro.jpg",
		"tomoehiyori.jpg","shiinaniki.jpg","shiratoriaira.jpg","saegusaibara.jpg","aoihinata.jpg",
		"hasumikeito.jpg","aoiyuuta.jpg","hibikiwataru.jpg","sazanamijun.jpg","hakazekaoru.jpg",
		"otogariadonis.jpg","extension.js","MAIN.JS","package.js","礼濑真宵.jpg","风早巽.jpg"],
	size:"20.1MB"
};