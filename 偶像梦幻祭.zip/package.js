extension["偶像梦幻祭"]={
	intro:"《偶像梦幻祭》是一款乐元素公司（Happy Elements）研发的女性向偶像养成音乐手游",
	author:"小叶",
	netdisk:"https://github.com/jy-umehara/noname-extensions/raw/main/%E5%81%B6%E5%83%8F%E6%A2%A6%E5%B9%BB%E7%A5%AD.zip",
	forum:"",
	version:"0.51",
	files:["sazanamijun.jpg","kanzakisouma.jpg","fushimiyuzuru.jpg","hakazekaoru.jpg","rannagisa.jpg",
		"ayasemayoi.jpg","kiryukuro.jpg","himeru.jpg","shiratoriaira.jpg","otogariadonis.jpg",
		"amagirinne.jpg","shiinaniki.jpg","aoiyuuta.jpg","tenshouineichi.jpg","ogamikoga.jpg",
		"himemiyatori.jpg","kazehayatatsumi.jpg","hibikiwataru.jpg","amagihiiro.jpg","sakumarei.jpg",
		"hasumikeito.jpg","aoihinata.jpg","saegusaibara.jpg","hidakahokuto.jpg","tomoehiyori.jpg",
		"oukawakohaku.jpg","akehoshisubaru.jpg","extension.js","MAIN.JS","package.js","update.md",
		"礼濑真宵.jpg","风早巽.jpg"],
	size:"20.9MB"
};